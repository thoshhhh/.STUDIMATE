import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAppContext } from '../contexts/AppContext';
import { Calendar, Clock } from 'lucide-react';

const ExamDetailsPage = () => {
  const { studentDetails, examDetails, setExamDetails } = useAppContext();
  const navigate = useNavigate();
  
  const [formData, setFormData] = useState({
    daysLeft: examDetails.daysLeft || '',
    hoursPerDay: examDetails.hoursPerDay || ''
  });
  
  const [formErrors, setFormErrors] = useState({
    daysLeft: '',
    hoursPerDay: ''
  });

  // Redirect if not logged in
  useEffect(() => {
    if (!studentDetails.rollNumber) {
      navigate('/login');
    }
  }, [studentDetails.rollNumber, navigate]);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
    
    // Clear error when user enters a value
    if (value) {
      setFormErrors(prev => ({ ...prev, [name]: '' }));
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    // Validate form
    const daysLeftNum = Number(formData.daysLeft);
    const hoursPerDayNum = Number(formData.hoursPerDay);
    
    const errors = {
      daysLeft: !formData.daysLeft ? 'Please enter days left for exam' : 
                daysLeftNum < 1 ? 'Days should be at least 1' :
                daysLeftNum > 180 ? 'Days should be less than 180' : '',
                
      hoursPerDay: !formData.hoursPerDay ? 'Please enter hours per day' : 
                  hoursPerDayNum < 1 ? 'Hours should be at least 1' :
                  hoursPerDayNum > 16 ? 'Hours should be less than 16' : ''
    };
    
    setFormErrors(errors);
    
    // If any errors, stop submission
    if (errors.daysLeft || errors.hoursPerDay) {
      return;
    }
    
    // Update exam details in context
    setExamDetails({
      daysLeft: daysLeftNum,
      hoursPerDay: hoursPerDayNum
    });
    
    // Navigate to material page
    navigate('/material');
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 py-12 px-4 sm:px-6 lg:px-8">
      <div className="max-w-md mx-auto">
        <div className="text-center">
          <Calendar className="h-12 w-12 text-indigo-600 mx-auto" />
          <h2 className="mt-2 text-3xl font-extrabold text-gray-900">
            Exam Timeline
          </h2>
          <p className="mt-2 text-sm text-gray-600">
            Let us know your exam schedule to customize your study plan
          </p>
        </div>
        
        <div className="mt-8 bg-white py-8 px-4 shadow-lg rounded-lg sm:px-10">
          <form className="space-y-6" onSubmit={handleSubmit}>
            {/* Days Left Input */}
            <div>
              <label htmlFor="daysLeft" className="block text-sm font-medium text-gray-700">
                Days Left Until Exam
              </label>
              <div className="mt-1 relative rounded-md shadow-sm">
                <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                  <Calendar className="h-5 w-5 text-gray-400" />
                </div>
                <input
                  type="number"
                  id="daysLeft"
                  name="daysLeft"
                  value={formData.daysLeft}
                  onChange={handleChange}
                  className="block w-full pl-10 pr-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm"
                  placeholder="Enter number of days"
                  min="1"
                  max="180"
                />
              </div>
              {formErrors.daysLeft && (
                <p className="mt-2 text-sm text-red-600">{formErrors.daysLeft}</p>
              )}
            </div>
            
            {/* Hours Per Day Input */}
            <div>
              <label htmlFor="hoursPerDay" className="block text-sm font-medium text-gray-700">
                Study Hours Per Day
              </label>
              <div className="mt-1 relative rounded-md shadow-sm">
                <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                  <Clock className="h-5 w-5 text-gray-400" />
                </div>
                <input
                  type="number"
                  id="hoursPerDay"
                  name="hoursPerDay"
                  value={formData.hoursPerDay}
                  onChange={handleChange}
                  className="block w-full pl-10 pr-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm"
                  placeholder="Enter hours available per day"
                  min="1"
                  max="16"
                />
              </div>
              {formErrors.hoursPerDay && (
                <p className="mt-2 text-sm text-red-600">{formErrors.hoursPerDay}</p>
              )}
            </div>
            
            <div>
              <button
                type="submit"
                className="w-full flex justify-center py-2 px-4 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-indigo-600 hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500 transition-colors duration-200"
              >
                Generate Study Plan
              </button>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
};

export default ExamDetailsPage;