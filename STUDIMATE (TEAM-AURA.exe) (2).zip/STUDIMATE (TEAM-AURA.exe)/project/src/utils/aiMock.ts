import { Subject, DayPlan } from '../contexts/AppContext';

// Type for the mock AI function parameters
type GenerateMaterialParams = {
  subjects: Subject[];
  daysLeft: number;
  hoursPerDay: number;
};

// Function to generate mock study material
export const generateStudyMaterial = ({ subjects, daysLeft, hoursPerDay }: GenerateMaterialParams): DayPlan[] => {
  const selectedTopics = subjects.flatMap(subject => 
    subject.topics
      .filter(topic => topic.selected)
      .map(topic => ({
        subjectId: subject.id,
        subjectName: subject.name,
        topicId: topic.id,
        topicName: topic.name,
        completed: false
      }))
  );

  // Calculate topics per day (simple distribution)
  const totalTopics = selectedTopics.length;
  const topicsPerDay = Math.ceil(totalTopics / daysLeft);

  // Distribute topics across available days
  const dayPlans: DayPlan[] = [];
  
  for (let day = 1; day <= daysLeft; day++) {
    const startIndex = (day - 1) * topicsPerDay;
    const endIndex = Math.min(startIndex + topicsPerDay, totalTopics);
    
    // Skip days with no topics
    if (startIndex >= totalTopics) break;
    
    const dayTopics = selectedTopics.slice(startIndex, endIndex);
    
    dayPlans.push({
      day,
      topics: dayTopics
    });
  }

  return dayPlans;
};

// Mock function to generate additional detailed material for each topic
export const generateTopicMaterial = (topicName: string): string => {
  // In a real app, this would be an AI-generated response
  return `
## ${topicName} Summary

This is a mock summary of ${topicName}. In a real application, this would contain AI-generated content like key points, formulas, and explanations.

### Key Concepts
- Important concept 1 related to ${topicName}
- Important concept 2 related to ${topicName}
- Important concept 3 related to ${topicName}

### Practice Problems
1. Sample problem related to ${topicName}
2. Another sample problem related to ${topicName}

### Memory Aids
- Mnemonic device for remembering ${topicName} concepts
- Visual aid description for ${topicName}
  `;
};