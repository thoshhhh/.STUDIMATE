import { Subject } from '../contexts/AppContext';

// Mock syllabus data with subject and topics
const syllabusData: Subject[] = [
  {
    id: "cs101",
    name: "Introduction to Computer Science",
    topics: [
      { id: "cs101-1", name: "Computing Fundamentals", selected: false },
      { id: "cs101-2", name: "Data Representation", selected: false },
      { id: "cs101-3", name: "Algorithm Basics", selected: false },
      { id: "cs101-4", name: "Programming Concepts", selected: false },
      { id: "cs101-5", name: "Computer Architecture", selected: false },
    ]
  },
  {
    id: "math201",
    name: "Discrete Mathematics",
    topics: [
      { id: "math201-1", name: "Set Theory", selected: false },
      { id: "math201-2", name: "Logic and Proofs", selected: false },
      { id: "math201-3", name: "Functions and Relations", selected: false },
      { id: "math201-4", name: "Graph Theory", selected: false },
      { id: "math201-5", name: "Combinatorics", selected: false },
    ]
  },
  {
    id: "ds202",
    name: "Data Structures",
    topics: [
      { id: "ds202-1", name: "Arrays and Linked Lists", selected: false },
      { id: "ds202-2", name: "Stacks and Queues", selected: false },
      { id: "ds202-3", name: "Trees and Graphs", selected: false },
      { id: "ds202-4", name: "Hashing", selected: false },
      { id: "ds202-5", name: "Sorting Algorithms", selected: false },
    ]
  },
  {
    id: "algo303",
    name: "Algorithm Design and Analysis",
    topics: [
      { id: "algo303-1", name: "Divide and Conquer", selected: false },
      { id: "algo303-2", name: "Greedy Algorithms", selected: false },
      { id: "algo303-3", name: "Dynamic Programming", selected: false },
      { id: "algo303-4", name: "Complexity Analysis", selected: false },
      { id: "algo303-5", name: "NP-Completeness", selected: false },
    ]
  },
  {
    id: "db404",
    name: "Database Systems",
    topics: [
      { id: "db404-1", name: "Relational Model", selected: false },
      { id: "db404-2", name: "SQL", selected: false },
      { id: "db404-3", name: "Normalization", selected: false },
      { id: "db404-4", name: "Transaction Processing", selected: false },
      { id: "db404-5", name: "Query Optimization", selected: false },
    ]
  },
  {
    id: "os405",
    name: "Operating Systems",
    topics: [
      { id: "os405-1", name: "Process Management", selected: false },
      { id: "os405-2", name: "Memory Management", selected: false },
      { id: "os405-3", name: "File Systems", selected: false },
      { id: "os405-4", name: "I/O Systems", selected: false },
      { id: "os405-5", name: "Virtualization", selected: false },
    ]
  }
];

export default syllabusData;