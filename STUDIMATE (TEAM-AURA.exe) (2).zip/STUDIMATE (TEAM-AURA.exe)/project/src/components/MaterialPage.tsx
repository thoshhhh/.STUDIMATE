import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAppContext } from '../contexts/AppContext';
import { generateStudyMaterial, generateTopicMaterial } from '../utils/aiMock';
import { Lightbulb, BookOpen, Calendar, CheckCircle, ChevronRight } from 'lucide-react';

const MaterialPage = () => {
  const { 
    studentDetails, 
    subjects, 
    examDetails, 
    studyMaterial, 
    setStudyMaterial,
    toggleTopicCompletion
  } = useAppContext();
  
  const navigate = useNavigate();
  const [isGenerating, setIsGenerating] = useState(false);
  const [selectedDay, setSelectedDay] = useState<number | null>(null);
  const [selectedTopic, setSelectedTopic] = useState<string | null>(null);
  const [topicMaterial, setTopicMaterial] = useState('');

  // Redirect if not logged in
  useEffect(() => {
    if (!studentDetails.rollNumber) {
      navigate('/login');
    }
  }, [studentDetails.rollNumber, navigate]);

  // Check if all required data is available
  const hasRequiredData = 
    studentDetails.rollNumber && 
    subjects.some(subject => subject.topics.some(topic => topic.selected)) &&
    examDetails.daysLeft > 0 && 
    examDetails.hoursPerDay > 0;

  // Generate material if not already generated
  const handleGenerateMaterial = () => {
    if (!hasRequiredData) {
      alert('Please complete all previous steps before generating study material.');
      return;
    }

    setIsGenerating(true);
    
    // Simulate API call delay
    setTimeout(() => {
      const dayPlans = generateStudyMaterial({
        subjects,
        daysLeft: examDetails.daysLeft,
        hoursPerDay: examDetails.hoursPerDay
      });
      
      setStudyMaterial({
        dayPlans,
        generated: true
      });
      
      setIsGenerating(false);
      
      // Select the first day by default
      if (dayPlans.length > 0) {
        setSelectedDay(dayPlans[0].day);
      }
    }, 1500);
  };

  // Calculate progress
  const totalTopics = studyMaterial.dayPlans.reduce(
    (total, day) => total + day.topics.length, 0
  );
  
  const completedTopics = studyMaterial.dayPlans.reduce(
    (total, day) => total + day.topics.filter(topic => topic.completed).length, 0
  );
  
  const progressPercentage = totalTopics > 0 
    ? Math.round((completedTopics / totalTopics) * 100) 
    : 0;

  // Handle topic selection for detailed view
  const handleTopicClick = (topicName: string) => {
    setSelectedTopic(topicName);
    setTopicMaterial(generateTopicMaterial(topicName));
  };

  // Navigate to calendar view
  const handleViewCalendar = () => {
    navigate('/calendar');
  };

  const selectedDayPlan = selectedDay !== null 
    ? studyMaterial.dayPlans.find(plan => plan.day === selectedDay) 
    : null;

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 py-6 px-4 sm:px-6 lg:px-8">
      <div className="max-w-6xl mx-auto">
        <div className="text-center mb-8">
          <Lightbulb className="h-12 w-12 text-indigo-600 mx-auto" />
          <h2 className="mt-2 text-3xl font-extrabold text-gray-900">
            Your Study Material
          </h2>
          <p className="mt-2 text-sm text-gray-600">
            Personalized study plan based on your selected topics
          </p>
        </div>
        
        {!studyMaterial.generated ? (
          <div className="mt-8 bg-white py-8 px-6 shadow-lg rounded-lg text-center">
            <BookOpen className="h-16 w-16 text-indigo-500 mx-auto mb-4" />
            <h3 className="text-xl font-medium text-gray-900 mb-4">
              Generate Your Personalized Study Plan
            </h3>
            <p className="text-gray-600 mb-6">
              Based on your selected topics and exam timeline, we'll create a day-by-day study plan to help you prepare effectively.
            </p>
            <button
              onClick={handleGenerateMaterial}
              disabled={isGenerating || !hasRequiredData}
              className="inline-flex items-center px-4 py-2 border border-transparent text-base font-medium rounded-md shadow-sm text-white bg-indigo-600 hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500 transition-colors duration-200 disabled:opacity-50 disabled:cursor-not-allowed"
            >
              {isGenerating ? 'Generating...' : 'Generate Study Plan'}
            </button>
          </div>
        ) : (
          <div className="lg:flex lg:space-x-6">
            {/* Left sidebar - Progress and day selection */}
            <div className="lg:w-64 mb-6 lg:mb-0">
              <div className="bg-white p-6 rounded-lg shadow-md mb-4">
                <h3 className="text-lg font-medium text-gray-900 mb-2">Progress</h3>
                <div className="w-full bg-gray-200 rounded-full h-2.5">
                  <div 
                    className="bg-indigo-600 h-2.5 rounded-full" 
                    style={{ width: `${progressPercentage}%` }}
                  ></div>
                </div>
                <p className="text-sm text-gray-600 mt-2">
                  {completedTopics} of {totalTopics} topics completed ({progressPercentage}%)
                </p>
                
                <button
                  onClick={handleViewCalendar}
                  className="mt-4 inline-flex items-center px-3 py-1.5 text-sm font-medium rounded-md text-indigo-700 bg-indigo-100 hover:bg-indigo-200 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500 transition-colors duration-150"
                >
                  <Calendar className="h-4 w-4 mr-1" />
                  View Calendar
                </button>
              </div>
              
              <div className="bg-white p-6 rounded-lg shadow-md">
                <h3 className="text-lg font-medium text-gray-900 mb-3">Study Days</h3>
                <nav className="space-y-1">
                  {studyMaterial.dayPlans.map((dayPlan) => {
                    const dayTopics = dayPlan.topics.length;
                    const completedDayTopics = dayPlan.topics.filter(t => t.completed).length;
                    
                    return (
                      <button
                        key={dayPlan.day}
                        onClick={() => setSelectedDay(dayPlan.day)}
                        className={`w-full flex items-center px-3 py-2 text-sm font-medium rounded-md ${
                          selectedDay === dayPlan.day
                            ? 'bg-indigo-100 text-indigo-700'
                            : 'text-gray-700 hover:bg-gray-100'
                        }`}
                      >
                        <span className="truncate">Day {dayPlan.day}</span>
                        <span className="ml-auto inline-block py-0.5 px-2 text-xs rounded-full bg-gray-100">
                          {completedDayTopics}/{dayTopics}
                        </span>
                      </button>
                    );
                  })}
                </nav>
              </div>
            </div>
            
            {/* Main content area */}
            <div className="flex-1">
              <div className="bg-white rounded-lg shadow-md overflow-hidden">
                {/* Day plan header */}
                {selectedDayPlan && (
                  <div className="bg-gray-50 px-6 py-4 border-b">
                    <h3 className="text-lg font-medium text-gray-900">Day {selectedDayPlan.day} Study Plan</h3>
                    <p className="text-sm text-gray-600">
                      {selectedDayPlan.topics.length} topics • {examDetails.hoursPerDay} hours
                    </p>
                  </div>
                )}
                
                {/* Main content */}
                <div className="divide-y divide-gray-200">
                  {selectedDayPlan?.topics.map((topic, index) => (
                    <div key={topic.topicId} className="p-6">
                      <div className="flex items-start">
                        <button
                          onClick={() => toggleTopicCompletion(selectedDayPlan.day, index)}
                          className={`flex-shrink-0 h-5 w-5 rounded-full ${
                            topic.completed ? 'text-green-500' : 'text-gray-300'
                          }`}
                        >
                          <CheckCircle className="h-5 w-5" />
                        </button>
                        
                        <div className="ml-3 flex-1">
                          <div className="flex items-center justify-between">
                            <div>
                              <p className="text-sm text-gray-500">{topic.subjectName}</p>
                              <h4 className="text-base font-medium text-gray-900 mt-1">{topic.topicName}</h4>
                            </div>
                            <button
                              onClick={() => handleTopicClick(topic.topicName)}
                              className="inline-flex items-center text-sm text-indigo-600 hover:text-indigo-800"
                            >
                              <span>View Details</span>
                              <ChevronRight className="h-4 w-4 ml-1" />
                            </button>
                          </div>
                        </div>
                      </div>
                    </div>
                  ))}
                  
                  {selectedDayPlan?.topics.length === 0 && (
                    <div className="p-6 text-center text-gray-500">
                      No topics planned for this day.
                    </div>
                  )}
                  
                  {!selectedDayPlan && studyMaterial.dayPlans.length > 0 && (
                    <div className="p-6 text-center text-gray-500">
                      Select a day from the sidebar to view your study plan.
                    </div>
                  )}
                </div>
              </div>
              
              {/* Topic detail view */}
              {selectedTopic && (
                <div className="mt-6 bg-white rounded-lg shadow-md p-6">
                  <h3 className="text-lg font-medium text-gray-900 mb-4">{selectedTopic} Details</h3>
                  <div className="prose prose-indigo max-w-none">
                    {topicMaterial.split('\n').map((line, index) => {
                      if (line.startsWith('## ')) {
                        return <h2 key={index} className="text-xl font-bold mt-4 mb-2">{line.substring(3)}</h2>;
                      }
                      if (line.startsWith('### ')) {
                        return <h3 key={index} className="text-lg font-semibold mt-3 mb-2">{line.substring(4)}</h3>;
                      }
                      if (line.startsWith('- ')) {
                        return <li key={index} className="ml-4">{line.substring(2)}</li>;
                      }
                      if (line.startsWith('1. ') || line.startsWith('2. ')) {
                        return <li key={index} className="ml-4 list-decimal">{line.substring(3)}</li>;
                      }
                      if (line === '') {
                        return <br key={index} />;
                      }
                      return <p key={index} className="mb-2">{line}</p>;
                    })}
                  </div>
                </div>
              )}
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default MaterialPage;