import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAppContext } from '../contexts/AppContext';
import { BookOpen, Check, ChevronDown, ChevronUp } from 'lucide-react';
import syllabusData from '../data/syllabusData';

const SyllabusPage = () => {
  const { studentDetails, subjects, setSubjects, toggleTopicSelection } = useAppContext();
  const navigate = useNavigate();
  
  const [expandedSubjects, setExpandedSubjects] = useState<Record<string, boolean>>({});
  const [selectedCount, setSelectedCount] = useState(0);

  // Redirect if not logged in
  useEffect(() => {
    if (!studentDetails.rollNumber) {
      navigate('/login');
    }
  }, [studentDetails.rollNumber, navigate]);

  // Load syllabus data on first render if not already in context
  useEffect(() => {
    if (subjects.length === 0) {
      setSubjects(syllabusData);
      
      // Initialize all subjects as expanded
      const initialExpanded: Record<string, boolean> = {};
      syllabusData.forEach(subject => {
        initialExpanded[subject.id] = true;
      });
      setExpandedSubjects(initialExpanded);
    } else {
      // Count selected topics
      let count = 0;
      subjects.forEach(subject => {
        subject.topics.forEach(topic => {
          if (topic.selected) count++;
        });
      });
      setSelectedCount(count);
      
      // Initialize expanded state from existing subjects
      const initialExpanded: Record<string, boolean> = {};
      subjects.forEach(subject => {
        initialExpanded[subject.id] = true;
      });
      setExpandedSubjects(initialExpanded);
    }
  }, [subjects, setSubjects]);

  const toggleSubjectExpand = (subjectId: string) => {
    setExpandedSubjects(prev => ({
      ...prev,
      [subjectId]: !prev[subjectId]
    }));
  };

  const handleTopicToggle = (subjectId: string, topicId: string) => {
    toggleTopicSelection(subjectId, topicId);
    
    // Update selected count
    const subject = subjects.find(s => s.id === subjectId);
    const topic = subject?.topics.find(t => t.id === topicId);
    
    if (topic) {
      setSelectedCount(prev => 
        topic.selected ? prev - 1 : prev + 1
      );
    }
  };

  const handleContinue = () => {
    if (selectedCount === 0) {
      alert("Please select at least one topic to continue.");
      return;
    }
    
    navigate('/exam-details');
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 py-12 px-4 sm:px-6 lg:px-8">
      <div className="max-w-3xl mx-auto">
        <div className="text-center">
          <BookOpen className="h-12 w-12 text-indigo-600 mx-auto" />
          <h2 className="mt-2 text-3xl font-extrabold text-gray-900">
            Select Topics to Study
          </h2>
          <p className="mt-2 text-sm text-gray-600">
            Choose the topics you want to include in your study plan
          </p>
        </div>
        
        <div className="mt-8 bg-white py-6 px-4 shadow-lg rounded-lg sm:px-6">
          {subjects.map(subject => (
            <div key={subject.id} className="mb-4 border rounded-lg overflow-hidden">
              <div 
                className="bg-gray-50 p-4 cursor-pointer flex justify-between items-center"
                onClick={() => toggleSubjectExpand(subject.id)}
              >
                <h3 className="text-lg font-medium text-gray-900">{subject.name}</h3>
                {expandedSubjects[subject.id] ? 
                  <ChevronUp className="h-5 w-5 text-gray-500" /> : 
                  <ChevronDown className="h-5 w-5 text-gray-500" />
                }
              </div>
              
              {expandedSubjects[subject.id] && (
                <div className="p-4 space-y-2">
                  {subject.topics.map(topic => (
                    <div 
                      key={topic.id} 
                      className="flex items-center space-x-3 p-2 hover:bg-gray-50 rounded-md cursor-pointer"
                      onClick={() => handleTopicToggle(subject.id, topic.id)}
                    >
                      <div className={`h-5 w-5 border rounded flex items-center justify-center ${
                        topic.selected ? 'bg-indigo-600 border-indigo-600' : 'border-gray-300'
                      }`}>
                        {topic.selected && <Check className="h-4 w-4 text-white" />}
                      </div>
                      <span className="text-gray-700">{topic.name}</span>
                    </div>
                  ))}
                </div>
              )}
            </div>
          ))}
          
          <div className="mt-6 flex justify-between items-center">
            <p className="text-sm text-gray-600">
              {selectedCount} topics selected
            </p>
            <button
              onClick={handleContinue}
              className="flex justify-center py-2 px-4 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-indigo-600 hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500 transition-colors duration-200"
            >
              Continue
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default SyllabusPage;