import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAppContext } from '../contexts/AppContext';
import { ClipboardList } from 'lucide-react';

const StudentDetailsPage = () => {
  const { studentDetails, setStudentDetails } = useAppContext();
  const navigate = useNavigate();
  
  const [formData, setFormData] = useState({
    year: studentDetails.year || '',
    branch: studentDetails.branch || '',
    semester: studentDetails.semester || ''
  });
  
  const [formErrors, setFormErrors] = useState({
    year: '',
    branch: '',
    semester: ''
  });

  // Redirect if not logged in
  useEffect(() => {
    if (!studentDetails.rollNumber) {
      navigate('/login');
    }
  }, [studentDetails.rollNumber, navigate]);

  const handleChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
    
    // Clear error when user selects an option
    if (value) {
      setFormErrors(prev => ({ ...prev, [name]: '' }));
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    // Validate form
    const errors = {
      year: !formData.year ? 'Please select your year' : '',
      branch: !formData.branch ? 'Please select your branch' : '',
      semester: !formData.semester ? 'Please select your semester' : ''
    };
    
    setFormErrors(errors);
    
    // If any errors, stop submission
    if (errors.year || errors.branch || errors.semester) {
      return;
    }
    
    // Update student details in context
    setStudentDetails({
      ...studentDetails,
      ...formData
    });
    
    // Navigate to syllabus page
    navigate('/syllabus');
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 py-12 px-4 sm:px-6 lg:px-8">
      <div className="max-w-md mx-auto">
        <div className="text-center">
          <ClipboardList className="h-12 w-12 text-indigo-600 mx-auto" />
          <h2 className="mt-2 text-3xl font-extrabold text-gray-900">
            Student Details
          </h2>
          <p className="mt-2 text-sm text-gray-600">
            Please provide your academic information
          </p>
        </div>
        
        <div className="mt-8 bg-white py-8 px-4 shadow-lg rounded-lg sm:px-10">
          <form className="space-y-6" onSubmit={handleSubmit}>
            {/* Year Selection */}
            <div>
              <label htmlFor="year" className="block text-sm font-medium text-gray-700">
                Year
              </label>
              <select
                id="year"
                name="year"
                value={formData.year}
                onChange={handleChange}
                className="mt-1 block w-full pl-3 pr-10 py-2 text-base border-gray-300 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm rounded-md"
              >
                <option value="">Select Year</option>
                <option value="1">First Year</option>
                <option value="2">Second Year</option>
                <option value="3">Third Year</option>
                <option value="4">Fourth Year</option>
              </select>
              {formErrors.year && (
                <p className="mt-2 text-sm text-red-600">{formErrors.year}</p>
              )}
            </div>
            
            {/* Branch Selection */}
            <div>
              <label htmlFor="branch" className="block text-sm font-medium text-gray-700">
                Branch
              </label>
              <select
                id="branch"
                name="branch"
                value={formData.branch}
                onChange={handleChange}
                className="mt-1 block w-full pl-3 pr-10 py-2 text-base border-gray-300 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm rounded-md"
              >
                <option value="">Select Branch</option>
                <option value="CSE">Computer Science</option>
                <option value="ECE">Electronics</option>
                <option value="ME">Mechanical</option>
                <option value="CE">Civil</option>
                <option value="EE">Electrical</option>
              </select>
              {formErrors.branch && (
                <p className="mt-2 text-sm text-red-600">{formErrors.branch}</p>
              )}
            </div>
            
            {/* Semester Selection */}
            <div>
              <label htmlFor="semester" className="block text-sm font-medium text-gray-700">
                Semester
              </label>
              <select
                id="semester"
                name="semester"
                value={formData.semester}
                onChange={handleChange}
                className="mt-1 block w-full pl-3 pr-10 py-2 text-base border-gray-300 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm rounded-md"
              >
                <option value="">Select Semester</option>
                <option value="1">Semester 1</option>
                <option value="2">Semester 2</option>
                <option value="3">Semester 3</option>
                <option value="4">Semester 4</option>
                <option value="5">Semester 5</option>
                <option value="6">Semester 6</option>
                <option value="7">Semester 7</option>
                <option value="8">Semester 8</option>
              </select>
              {formErrors.semester && (
                <p className="mt-2 text-sm text-red-600">{formErrors.semester}</p>
              )}
            </div>
            
            <div>
              <button
                type="submit"
                className="w-full flex justify-center py-2 px-4 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-indigo-600 hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500 transition-colors duration-200"
              >
                Continue
              </button>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
};

export default StudentDetailsPage;