import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAppContext } from '../contexts/AppContext';
import { Calendar, CheckSquare, ArrowLeft, Star } from 'lucide-react';

const CalendarPage = () => {
  const { studentDetails, studyMaterial, toggleTopicCompletion } = useAppContext();
  const navigate = useNavigate();
  
  const [currentDate] = useState(new Date());
  const [streakCount, setStreakCount] = useState(0);
  
  // Redirect if not logged in
  useEffect(() => {
    if (!studentDetails.rollNumber) {
      navigate('/login');
    }
  }, [studentDetails.rollNumber, navigate]);

  // Redirect if no study material is generated
  useEffect(() => {
    if (!studyMaterial.generated) {
      navigate('/material');
    }
  }, [studyMaterial.generated, navigate]);

  // Calculate streaks (mock calculation - in a real app would be based on daily completions)
  useEffect(() => {
    const completed = studyMaterial.dayPlans.filter(day => 
      day.topics.some(topic => topic.completed)
    ).length;
    
    setStreakCount(completed);
  }, [studyMaterial]);

  // Generate dates for calendar
  const generateCalendarDays = () => {
    const days = [];
    const today = new Date();
    
    for (let i = 0; i < studyMaterial.dayPlans.length; i++) {
      const dayDate = new Date(today);
      dayDate.setDate(today.getDate() + i);
      days.push({
        date: dayDate,
        dayPlan: studyMaterial.dayPlans[i]
      });
    }
    
    return days;
  };
  
  const calendarDays = generateCalendarDays();
  
  // Format date to readable string
  const formatDate = (date: Date) => {
    return date.toLocaleDateString('en-US', { 
      weekday: 'short', 
      month: 'short', 
      day: 'numeric' 
    });
  };

  // Check if a day has completed topics
  const hasCompletedTopics = (dayPlan: typeof studyMaterial.dayPlans[0]) => {
    return dayPlan.topics.some(topic => topic.completed);
  };

  // Calculate completion percentage for a day
  const getDayCompletionPercentage = (dayPlan: typeof studyMaterial.dayPlans[0]) => {
    if (dayPlan.topics.length === 0) return 0;
    
    const completedCount = dayPlan.topics.filter(topic => topic.completed).length;
    return Math.round((completedCount / dayPlan.topics.length) * 100);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 py-6 px-4 sm:px-6 lg:px-8">
      <div className="max-w-4xl mx-auto">
        <div className="flex items-center justify-between mb-6">
          <button
            onClick={() => navigate('/material')}
            className="inline-flex items-center text-indigo-600 hover:text-indigo-800"
          >
            <ArrowLeft className="h-5 w-5 mr-1" />
            <span>Back to Study Material</span>
          </button>
          
          <div className="flex items-center">
            <div className="flex items-center bg-indigo-100 text-indigo-800 px-3 py-1 rounded-md">
              <Star className="h-5 w-5 mr-2 text-yellow-500" />
              <span className="font-medium">{streakCount} day streak</span>
            </div>
          </div>
        </div>
        
        <div className="text-center mb-8">
          <Calendar className="h-12 w-12 text-indigo-600 mx-auto" />
          <h2 className="mt-2 text-3xl font-extrabold text-gray-900">
            Study Calendar
          </h2>
          <p className="mt-2 text-sm text-gray-600">
            Track your progress and maintain your study streak
          </p>
        </div>
        
        <div className="bg-white rounded-lg shadow-lg overflow-hidden">
          <div className="p-6 bg-gray-50 border-b">
            <div className="flex items-center justify-between">
              <h3 className="text-lg font-medium text-gray-900">
                {currentDate.toLocaleDateString('en-US', { month: 'long', year: 'numeric' })}
              </h3>
            </div>
          </div>
          
          <div className="p-6">
            <div className="space-y-4">
              {calendarDays.map(({ date, dayPlan }) => (
                <div 
                  key={dayPlan.day}
                  className="border rounded-lg overflow-hidden hover:shadow-md transition-shadow duration-200"
                >
                  <div className="bg-gray-50 px-4 py-3 flex items-center justify-between">
                    <div>
                      <span className="font-medium">Day {dayPlan.day}</span>
                      <span className="text-gray-500 ml-2 text-sm">{formatDate(date)}</span>
                    </div>
                    <div className="flex items-center text-sm">
                      <div className="w-16 bg-gray-200 rounded-full h-2">
                        <div 
                          className="bg-indigo-600 h-2 rounded-full" 
                          style={{ width: `${getDayCompletionPercentage(dayPlan)}%` }}
                        ></div>
                      </div>
                      <span className="ml-2 text-gray-600">
                        {dayPlan.topics.filter(t => t.completed).length}/{dayPlan.topics.length}
                      </span>
                    </div>
                  </div>
                  
                  <div className="px-4 py-3 divide-y divide-gray-100">
                    {dayPlan.topics.length > 0 ? (
                      dayPlan.topics.map((topic, index) => (
                        <div 
                          key={topic.topicId}
                          className="py-2 flex items-center"
                        >
                          <button
                            onClick={() => toggleTopicCompletion(dayPlan.day, index)}
                            className="flex items-center"
                          >
                            <div className={`h-5 w-5 rounded border flex items-center justify-center ${
                              topic.completed 
                                ? 'bg-indigo-600 border-indigo-600 text-white' 
                                : 'border-gray-300'
                            }`}>
                              {topic.completed && <CheckSquare className="h-4 w-4" />}
                            </div>
                          </button>
                          
                          <div className="ml-3">
                            <p className={`text-sm ${topic.completed ? 'line-through text-gray-400' : 'text-gray-700'}`}>
                              {topic.topicName}
                            </p>
                            <p className="text-xs text-gray-500">{topic.subjectName}</p>
                          </div>
                        </div>
                      ))
                    ) : (
                      <div className="py-3 text-center text-gray-500 text-sm">
                        No topics scheduled for this day
                      </div>
                    )}
                  </div>
                  
                  {hasCompletedTopics(dayPlan) && (
                    <div className="bg-green-50 px-4 py-2 text-green-800 text-sm border-t border-green-100">
                      <div className="flex items-center">
                        <CheckSquare className="h-4 w-4 mr-2" />
                        <span>Great job on your progress today!</span>
                      </div>
                    </div>
                  )}
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default CalendarPage;