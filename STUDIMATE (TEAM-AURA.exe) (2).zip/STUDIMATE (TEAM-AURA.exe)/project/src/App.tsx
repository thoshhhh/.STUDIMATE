import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { AppProvider, useAppContext } from './contexts/AppContext';
import LoginPage from './components/LoginPage';
import StudentDetailsPage from './components/StudentDetailsPage';
import SyllabusPage from './components/SyllabusPage';
import ExamDetailsPage from './components/ExamDetailsPage';
import MaterialPage from './components/MaterialPage';
import CalendarPage from './components/CalendarPage';
import Navbar from './components/Navbar';

// Protected route component
const ProtectedRoute = ({ children }: { children: React.ReactNode }) => {
  const { isLoggedIn } = useAppContext();
  
  if (!isLoggedIn) {
    return <Navigate to="/login" replace />;
  }
  
  return <>{children}</>;
};

// App with context
function AppWithContext() {
  return (
    <AppProvider>
      <AppContent />
    </AppProvider>
  );
}

// Main app content
function AppContent() {
  return (
    <Router>
      <div className="min-h-screen bg-gray-50">
        <Navbar />
        <Routes>
          <Route path="/login" element={<LoginPage />} />
          <Route path="/details" element={
            <ProtectedRoute>
              <StudentDetailsPage />
            </ProtectedRoute>
          } />
          <Route path="/syllabus" element={
            <ProtectedRoute>
              <SyllabusPage />
            </ProtectedRoute>
          } />
          <Route path="/exam-details" element={
            <ProtectedRoute>
              <ExamDetailsPage />
            </ProtectedRoute>
          } />
          <Route path="/material" element={
            <ProtectedRoute>
              <MaterialPage />
            </ProtectedRoute>
          } />
          <Route path="/calendar" element={
            <ProtectedRoute>
              <CalendarPage />
            </ProtectedRoute>
          } />
          <Route path="/" element={<Navigate to="/login" replace />} />
        </Routes>
      </div>
    </Router>
  );
}

export default AppWithContext;