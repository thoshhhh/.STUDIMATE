import { createContext, useContext, ReactNode, useState, useEffect } from 'react';

// Define types for our context data
export type StudentDetails = {
  rollNumber: string;
  year: string;
  branch: string;
  semester: string;
};

export type ExamDetails = {
  daysLeft: number;
  hoursPerDay: number;
};

export type Topic = {
  id: string;
  name: string;
  selected: boolean;
};

export type Subject = {
  id: string;
  name: string;
  topics: Topic[];
};

export type DayPlan = {
  day: number;
  topics: { 
    subjectId: string;
    subjectName: string;
    topicId: string;
    topicName: string;
    completed: boolean;
  }[];
};

export type StudyMaterial = {
  dayPlans: DayPlan[];
  generated: boolean;
};

type AppContextType = {
  studentDetails: StudentDetails;
  setStudentDetails: (details: StudentDetails) => void;
  subjects: Subject[];
  setSubjects: (subjects: Subject[]) => void;
  examDetails: ExamDetails;
  setExamDetails: (details: ExamDetails) => void;
  studyMaterial: StudyMaterial;
  setStudyMaterial: (material: StudyMaterial) => void;
  toggleTopicSelection: (subjectId: string, topicId: string) => void;
  toggleTopicCompletion: (day: number, index: number) => void;
  isLoggedIn: boolean;
  logout: () => void;
};

// Create context with default values
const AppContext = createContext<AppContextType>({
  studentDetails: { rollNumber: '', year: '', branch: '', semester: '' },
  setStudentDetails: () => {},
  subjects: [],
  setSubjects: () => {},
  examDetails: { daysLeft: 0, hoursPerDay: 0 },
  setExamDetails: () => {},
  studyMaterial: { dayPlans: [], generated: false },
  setStudyMaterial: () => {},
  toggleTopicSelection: () => {},
  toggleTopicCompletion: () => {},
  isLoggedIn: false,
  logout: () => {},
});

// Custom hook to use the app context
export const useAppContext = () => useContext(AppContext);

// Provider component
export const AppProvider = ({ children }: { children: ReactNode }) => {
  // Initialize state from localStorage if available
  const [studentDetails, setStudentDetails] = useState<StudentDetails>(() => {
    const saved = localStorage.getItem('studentDetails');
    return saved ? JSON.parse(saved) : { rollNumber: '', year: '', branch: '', semester: '' };
  });

  const [subjects, setSubjects] = useState<Subject[]>(() => {
    const saved = localStorage.getItem('subjects');
    return saved ? JSON.parse(saved) : [];
  });

  const [examDetails, setExamDetails] = useState<ExamDetails>(() => {
    const saved = localStorage.getItem('examDetails');
    return saved ? JSON.parse(saved) : { daysLeft: 0, hoursPerDay: 0 };
  });

  const [studyMaterial, setStudyMaterial] = useState<StudyMaterial>(() => {
    const saved = localStorage.getItem('studyMaterial');
    return saved ? JSON.parse(saved) : { dayPlans: [], generated: false };
  });

  // Compute login status
  const isLoggedIn = studentDetails.rollNumber !== '';

  // Update localStorage when state changes
  useEffect(() => {
    localStorage.setItem('studentDetails', JSON.stringify(studentDetails));
  }, [studentDetails]);

  useEffect(() => {
    localStorage.setItem('subjects', JSON.stringify(subjects));
  }, [subjects]);

  useEffect(() => {
    localStorage.setItem('examDetails', JSON.stringify(examDetails));
  }, [examDetails]);

  useEffect(() => {
    localStorage.setItem('studyMaterial', JSON.stringify(studyMaterial));
  }, [studyMaterial]);

  // Function to toggle topic selection
  const toggleTopicSelection = (subjectId: string, topicId: string) => {
    setSubjects(prevSubjects => 
      prevSubjects.map(subject => {
        if (subject.id === subjectId) {
          return {
            ...subject,
            topics: subject.topics.map(topic => {
              if (topic.id === topicId) {
                return { ...topic, selected: !topic.selected };
              }
              return topic;
            }),
          };
        }
        return subject;
      })
    );
  };

  // Function to toggle topic completion in study plan
  const toggleTopicCompletion = (day: number, topicIndex: number) => {
    setStudyMaterial(prev => {
      const updatedDayPlans = prev.dayPlans.map(dayPlan => {
        if (dayPlan.day === day) {
          const updatedTopics = [...dayPlan.topics];
          if (updatedTopics[topicIndex]) {
            updatedTopics[topicIndex] = {
              ...updatedTopics[topicIndex],
              completed: !updatedTopics[topicIndex].completed
            };
          }
          return { ...dayPlan, topics: updatedTopics };
        }
        return dayPlan;
      });
      
      return { ...prev, dayPlans: updatedDayPlans };
    });
  };

  // Logout function
  const logout = () => {
    setStudentDetails({ rollNumber: '', year: '', branch: '', semester: '' });
    setStudyMaterial({ dayPlans: [], generated: false });
  };

  return (
    <AppContext.Provider value={{
      studentDetails,
      setStudentDetails,
      subjects,
      setSubjects,
      examDetails,
      setExamDetails,
      studyMaterial,
      setStudyMaterial,
      toggleTopicSelection,
      toggleTopicCompletion,
      isLoggedIn,
      logout
    }}>
      {children}
    </AppContext.Provider>
  );
};